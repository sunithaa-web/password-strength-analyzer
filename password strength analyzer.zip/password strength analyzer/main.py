import argparse
import sys
import os
import json

# Force UTF-8 output on Windows terminals to prevent cp1252 encode errors
if sys.platform == "win32":
    import io
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")
    sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding="utf-8", errors="replace")
import logging

from analyzer import analyze_password
from wordlist_generator import generate_custom_wordlist
from exporter import export_wordlist
from reports import generate_password_report

def main():
    # Setup Logging
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        handlers=[
            logging.FileHandler("password_analyzer.log", encoding="utf-8"),
            logging.StreamHandler(sys.stdout)
        ]
    )
    
    # Suppress verbose NLTK downloader output logs unless necessary
    logging.getLogger("nltk").setLevel(logging.WARNING)
    logger = logging.getLogger("PasswordAnalyzer")
    
    parser = argparse.ArgumentParser(
        description="Password Strength Analyzer with Custom Wordlist Generator",
        epilog="DISCLAIMER: This tool is intended solely for educational, defensive security, and password auditing purposes. Unauthorized password cracking is prohibited."
    )
    
    # GUI Mode (Default when no command is run)
    parser.add_argument("--gui", action="store_true", help="Launch the GUI interface")
    
    # Subparsers for commands
    subparsers = parser.add_subparsers(dest="command", help="Subcommand to run")
    
    # Subcommand: analyze
    parser_analyze = subparsers.add_parser("analyze", help="Analyze a password's strength and check for patterns")
    parser_analyze.add_argument("-p", "--password", required=True, type=str, help="Password to analyze")
    parser_analyze.add_argument("--first_name", type=str, default="", help="User's first name for personal leak check")
    parser_analyze.add_argument("--last_name", type=str, default="", help="User's last name for personal leak check")
    parser_analyze.add_argument("--nickname", type=str, default="", help="User's nickname for personal leak check")
    parser_analyze.add_argument("--pet_name", type=str, default="", help="User's pet name for personal leak check")
    parser_analyze.add_argument("--birth_year", type=str, default="", help="User's birth year for personal leak check")
    parser_analyze.add_argument("--city", type=str, default="", help="User's city for personal leak check")
    parser_analyze.add_argument("-r", "--report", action="store_true", help="Generate a password report file")
    parser_analyze.add_argument("-o", "--output_report", type=str, default="password_report.txt", help="Filename for the password report")
    
    # Subcommand: generate
    parser_generate = subparsers.add_parser("generate", help="Generate custom wordlist from user information")
    parser_generate.add_argument("--first_name", type=str, default="", help="First name")
    parser_generate.add_argument("--name", type=str, default="", help="Alias for first_name")
    parser_generate.add_argument("--last_name", type=str, default="", help="Last name")
    parser_generate.add_argument("--nickname", type=str, default="", help="Nickname")
    parser_generate.add_argument("--pet_name", type=str, default="", help="Pet name")
    parser_generate.add_argument("--pet", type=str, default="", help="Alias for pet_name")
    parser_generate.add_argument("--fav_team", type=str, default="", help="Favorite sports team")
    parser_generate.add_argument("--fav_movie", type=str, default="", help="Favorite movie")
    parser_generate.add_argument("--birth_date", type=str, default="", help="Birth date (DDMM)")
    parser_generate.add_argument("--birth_year", type=str, default="", help="Birth year (YYYY)")
    parser_generate.add_argument("--year", type=str, default="", help="Alias for birth_year")
    parser_generate.add_argument("--phone", type=str, default="", help="Phone digits (e.g. last 4)")
    parser_generate.add_argument("--city", type=str, default="", help="City")
    parser_generate.add_argument("--state", type=str, default="", help="State")
    parser_generate.add_argument("--max_words", type=int, default=100000, help="Maximum entries in wordlist (default 100,000)")
    
    # Subcommand: export
    parser_export = subparsers.add_parser("export", help="Display stats of the last generated wordlist")
    parser_export.add_argument("-d", "--output_dir", type=str, default="output", help="Directory where files are saved")
    
    # Parse args
    args = parser.parse_args()
    
    # Default to GUI mode if no command is given
    if args.gui or args.command is None:
        logger.info("Initializing Graphical User Interface...")
        try:
            import gui
            gui.launch_gui()
        except Exception as e:
            logger.error(f"Failed to launch GUI: {e}")
            print(f"Error launching GUI: {e}.\nEnsure customtkinter is installed, or execute CLI commands. Type 'python main.py -h' for CLI usage.", file=sys.stderr)
            sys.exit(1)
        return
        
    if args.command == "analyze":
        user_info = {
            "first_name": args.first_name,
            "last_name": args.last_name,
            "nickname": args.nickname,
            "pet_name": args.pet_name,
            "birth_year": args.birth_year,
            "city": args.city
        }
        
        logger.info("Running password analysis...")
        results = analyze_password(args.password, user_info)
        
        print("\n==================================================")
        print("PASSWORD ANALYSIS RESULTS")
        print("==================================================")
        print(f"Password Evaluated:    {args.password}")
        print(f"Length:                {results['length']} characters")
        print(f"Entropy:               {results['entropy']} bits ({results['entropy_category']})")
        print(f"zxcvbn Score:          {results['zxcvbn_score']}/4")
        print(f"Est. Crack Time:       {results['crack_time']}")
        print(f"Visual Score Score:    {results['score_100']}/100")
        print("--------------------------------------------------")
        
        if results['weaknesses']:
            print("Weaknesses Detected:")
            for w in results['weaknesses']:
                print(f"  [!] {w}")
        else:
            print("  [+] No pattern vulnerabilities or weaknesses detected!")
            
        print("--------------------------------------------------")
        if results['recommendations']:
            print("Suggestions & Actionable Steps:")
            for r in results['recommendations']:
                print(f"  [+] {r}")
        print("==================================================")
        
        if args.report:
            report_text = generate_password_report(results, args.output_report)
            print(f"Password report written to: {args.output_report}")
            logger.info(f"Saved audit report to {args.output_report}")
            
    elif args.command == "generate":
        # Resolve aliases
        f_name = args.first_name if args.first_name else args.name
        p_name = args.pet_name if args.pet_name else args.pet
        b_year = args.birth_year if args.birth_year else args.year
        
        user_info = {
            "first_name": f_name,
            "last_name": args.last_name,
            "nickname": args.nickname,
            "pet_name": p_name,
            "fav_team": args.fav_team,
            "fav_movie": args.fav_movie,
            "birth_date": args.birth_date,
            "birth_year": b_year,
            "phone": args.phone,
            "city": args.city,
            "state": args.state
        }
        
        # Verify if any inputs are provided
        if not any(user_info.values()):
            print("Error: You must provide at least one user information field to generate a wordlist.", file=sys.stderr)
            parser_generate.print_help()
            sys.exit(1)
            
        logger.info("Starting custom wordlist generation permutation sequence...")
        wordlist = generate_custom_wordlist(user_info, max_size=args.max_words)
        
        logger.info(f"Writing {len(wordlist)} generated entries to output/...")
        stats = export_wordlist(wordlist, output_dir="output", filename="custom_wordlist.txt")
        
        print("\n==================================================")
        print("WORDLIST GENERATION SUMMARY")
        print("==================================================")
        print(f"Total Words Generated:   {stats['total_words']:,}")
        print(f"Unique Words:            {stats['unique_words']:,}")
        print(f"Output File Size:        {stats['file_size_formatted']}")
        print(f"Output Path:             output/custom_wordlist.txt")
        print(f"Metadata Path:           output/stats.json")
        print("--------------------------------------------------")
        print("Estimated Cracking Coverage:")
        for speed, dur in stats['cracking_coverage'].items():
            clean_speed = speed.replace('_', ' ').title()
            print(f"  {clean_speed}: {dur}")
        print("==================================================")
        
    elif args.command == "export":
        stats_path = os.path.join(args.output_dir, "stats.json")
        wordlist_path = os.path.join(args.output_dir, "custom_wordlist.txt")
        
        if not os.path.exists(stats_path) or not os.path.exists(wordlist_path):
            print(f"Error: No wordlist has been exported yet in directory '{args.output_dir}'.", file=sys.stderr)
            print("Please run the 'generate' command first.", file=sys.stderr)
            sys.exit(1)
            
        with open(stats_path, 'r', encoding='utf-8') as f:
            stats = json.load(f)
            
        print("\n==================================================")
        print(f"LAST EXPORTED WORDLIST STATS (Source: {stats.get('source')})")
        print("==================================================")
        print(f"Date Created:            {stats.get('created')}")
        print(f"Total Words:             {stats.get('total_words', 0):,}")
        print(f"Unique Words:            {stats.get('unique_words', 0):,}")
        print(f"File Size:               {stats.get('file_size_formatted')}")
        print(f"File Location:           {wordlist_path}")
        print("--------------------------------------------------")
        print("Estimated Cracking Coverage:")
        for speed, dur in stats.get('cracking_coverage', {}).items():
            clean_speed = speed.replace('_', ' ').title()
            print(f"  {clean_speed}: {dur}")
        print("==================================================")

if __name__ == "__main__":
    main()
