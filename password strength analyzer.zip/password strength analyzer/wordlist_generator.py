from typing import Dict, Set
from mutations import run_permutation_engine

def generate_custom_wordlist(user_info: Dict[str, str], max_size: int = 100000) -> Set[str]:
    """
    Wrapper interface that cleans user inputs and invokes the mutation permutation engine.
    
    Expected keys in user_info:
        - first_name
        - last_name
        - nickname
        - pet_name
        - fav_team
        - fav_movie
        - birth_date (e.g., 1506)
        - birth_year (e.g., 2006)
        - phone (e.g., 9876)
        - city
        - state
    """
    # Clean input keys and values
    cleaned_info = {}
    for key, val in user_info.items():
        if val is not None:
            cleaned_info[key] = str(val).strip()
            
    # Delegate to the permutation engine
    return run_permutation_engine(cleaned_info, max_size=max_size)
