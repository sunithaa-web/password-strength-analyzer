import re
import string
import logging
import nltk
from typing import Dict, Any, List

import entropy

logger = logging.getLogger("PasswordAnalyzer")

# Lazy-loaded NLTK words set
_nltk_loaded = False
_common_words_set = set()

def init_nltk_words():
    """Initializes the dictionary words set, downloading from NLTK if necessary, with offline fallbacks."""
    global _nltk_loaded, _common_words_set
    if _nltk_loaded:
        return
    
    try:
        # Check if words corpus is already available
        from nltk.corpus import words
        _common_words_set = set(w.lower() for w in words.words())
        _nltk_loaded = True
        logger.info("Successfully loaded NLTK dictionary words.")
    except Exception:
        try:
            # Attempt to download quietly
            nltk.download('words', quiet=True)
            from nltk.corpus import words
            _common_words_set = set(w.lower() for w in words.words())
            _nltk_loaded = True
            logger.info("Downloaded and loaded NLTK dictionary words.")
        except Exception as e:
            # Robust fallback dictionary list
            logger.warning(f"NLTK download failed, using standard offline fallback list: {e}")
            _common_words_set = {
                "password", "admin", "admin123", "qwerty", "iloveyou", "football",
                "123456", "12345678", "password123", "welcome", "summer", "winter",
                "spring", "autumn", "login", "security", "shadow", "secret", "master",
                "oracle", "dragon", "monkey", "sunshine", "princess", "charlie",
                "hunter", "letmein", "soccer", "baseball", "yellow", "purple",
                "cookie", "sunset", "nature", "flower", "camera", "guitar"
            }
            _nltk_loaded = True

def check_repeated_characters(password: str) -> List[str]:
    """Detects characters repeated 3 or more times consecutively (e.g. 'aaaa', '111')."""
    matches = [m.group(0) for m in re.finditer(r'(.)\1\1+', password)]
    return list(set(matches))

def check_sequential_patterns(password: str) -> List[str]:
    """Detects sequential alphabetic or numeric runs of length >= 3 (e.g., 'abc', '321')."""
    pwd_lower = password.lower()
    alphabets = string.ascii_lowercase
    digits = string.digits
    sequences = [alphabets, alphabets[::-1], digits, digits[::-1]]
    matches = []
    
    for size in [4, 3]:
        for i in range(len(pwd_lower) - size + 1):
            sub = pwd_lower[i:i+size]
            for seq in sequences:
                if sub in seq:
                    # Skip sub if it's already contained in a longer sequence match
                    if not any(sub in m for m in matches):
                        matches.append(sub)
    return list(set(matches))

def check_keyboard_patterns(password: str) -> List[str]:
    """Detects adjacent keyboard layout sequences of length >= 3 (e.g., 'qwer', 'asdf')."""
    pwd_lower = password.lower()
    rows = [
        "qwertyuiop",
        "asdfghjkl",
        "zxcvbnm",
        "1234567890"
    ]
    # Include reversed layout rows
    all_rows = rows + [r[::-1] for r in rows]
    matches = []
    
    for size in [4, 3]:
        for i in range(len(pwd_lower) - size + 1):
            sub = pwd_lower[i:i+size]
            for row in all_rows:
                if sub in row:
                    if not any(sub in m for m in matches):
                        matches.append(sub)
    return list(set(matches))

def check_dictionary_words(password: str) -> List[str]:
    """
    Splits password by non-alpha characters and checks if any segment of length >= 4
    exists in the NLTK dictionary corpus. Returns lowercased unique matches only.
    """
    init_nltk_words()
    # Split by anything that isn't a letter
    chunks = re.split(r'[^a-zA-Z]', password)
    found_lower = set()  # Store lowercase versions to deduplicate

    for chunk in chunks:
        if len(chunk) >= 4:
            chunk_lower = chunk.lower()
            if chunk_lower in _common_words_set:
                found_lower.add(chunk_lower)

    # Also check the full alpha-only portion of password as a single word
    cleaned = re.sub(r'[^a-zA-Z]', '', password).lower()
    if len(cleaned) >= 4 and cleaned in _common_words_set:
        found_lower.add(cleaned)

    return sorted(found_lower)


def check_personal_info(password: str, user_info: Dict[str, str]) -> List[str]:
    """Checks if password contains elements of personal information provided in user_info."""
    matches = []
    if not user_info:
        return matches
        
    pwd_lower = password.lower()
    for key, val in user_info.items():
        if val and len(str(val)) >= 3:
            val_lower = str(val).lower()
            if val_lower in pwd_lower:
                matches.append(f"{key}: '{val}'")
    return matches

def analyze_password(password: str, user_info: Dict[str, str] = None) -> Dict[str, Any]:
    """
    Analyzes password strength using length check, diversity check, entropy,
    pattern matching, zxcvbn crack analysis, and personal info flags.
    Returns analysis results including weaknesses and recommendations.
    """
    if not password:
        return {
            "password": "",
            "length": 0,
            "diversity": [],
            "entropy": 0.0,
            "entropy_category": "Very Weak",
            "zxcvbn_score": 0,
            "crack_time": "Instant",
            "weaknesses": ["Password is empty"],
            "recommendations": ["Enter a password to begin analysis"],
            "score_100": 0
        }
        
    # Import zxcvbn locally to avoid issues during module import
    import zxcvbn
    
    length = len(password)
    
    # 1. Diversity Detection
    diversity = []
    if any(c.islower() for c in password):
        diversity.append("Lowercase Letters")
    if any(c.isupper() for c in password):
        diversity.append("Uppercase Letters")
    if any(c.isdigit() for c in password):
        diversity.append("Numbers")
    if any(c in string.punctuation for c in password):
        diversity.append("Symbols/Punctuation")
    if any(not (c.isalnum() or c in string.punctuation) for c in password):
        diversity.append("Special/Other characters")

    # 2. Entropy Analysis
    ent_val = entropy.calculate_entropy(password)
    ent_category = entropy.get_strength_category(ent_val)
    
    # 3. zxcvbn Analysis
    z_res = zxcvbn.zxcvbn(password)
    z_score = z_res.get("score", 0)
    
    # Get crack time estimation (prefer offline hashing rate 1e10/sec for GPU crack time)
    crack_times = z_res.get("crack_times_display", {})
    crack_time = crack_times.get("offline_fast_hashing_1e10_per_second", "Instant")
    
    # zxcvbn suggestions
    z_feedback = z_res.get("feedback", {})
    z_warning = z_feedback.get("warning", "")
    z_suggestions = z_feedback.get("suggestions", [])

    # 4. Pattern Vulnerability Checking
    repeats = check_repeated_characters(password)
    sequences = check_sequential_patterns(password)
    keyboards = check_keyboard_patterns(password)
    dict_words = check_dictionary_words(password)
    personal_leaks = check_personal_info(password, user_info)
    
    # 5. Compile Weaknesses & Recommendations
    weaknesses = []
    recommendations = []
    
    # Length recommendations
    if length < 8:
        weaknesses.append("Password is too short (less than 8 characters)")
        recommendations.append("Increase password length to at least 12-16 characters")
    elif length < 12:
        weaknesses.append("Password length is weak (8-12 characters)")
        recommendations.append("Increase password length to at least 12-16 characters")
        
    # Diversity recommendations
    missing_diversity = []
    if "Lowercase Letters" not in diversity:
        missing_diversity.append("lowercase letters")
    if "Uppercase Letters" not in diversity:
        missing_diversity.append("uppercase letters")
    if "Numbers" not in diversity:
        missing_diversity.append("digits")
    if "Symbols/Punctuation" not in diversity:
        missing_diversity.append("symbols/punctuation")
        
    if missing_diversity:
        weaknesses.append(f"Missing character diversity (missing: {', '.join(missing_diversity)})")
        recommendations.append(f"Add {', '.join(missing_diversity)} to diversify character usage")
        
    # Pattern-based warnings
    if z_warning:
        weaknesses.append(f"zxcvbn Warning: {z_warning}")
    for word in dict_words:
        weaknesses.append(f"Contains dictionary word: '{word}'")
    if dict_words:
        recommendations.append("Avoid common dictionary words or dictionary phrases")
        
    for rep in repeats:
        weaknesses.append(f"Contains repeated character run: '{rep}'")
    if repeats:
        recommendations.append("Remove repeated sequences of characters (e.g. 'aaaa', '111')")
        
    for seq in sequences:
        weaknesses.append(f"Contains sequential character run: '{seq}'")
    if sequences:
        recommendations.append("Avoid sequential strings (e.g. 'abc', '123')")
        
    for kbd in keyboards:
        weaknesses.append(f"Contains keyboard row pattern: '{kbd}'")
    if keyboards:
        recommendations.append("Avoid standard keyboard layouts patterns (e.g. 'qwerty')")
        
    for leak in personal_leaks:
        weaknesses.append(f"Exposes personal details ({leak})")
    if personal_leaks:
        recommendations.append("Do not incorporate personal names, years, cities, or nicknames")
        
    # Add zxcvbn suggestions to recommendations
    for sug in z_suggestions:
        if sug not in recommendations:
            recommendations.append(sug)

    # 6. Unified 0-100 Score Mapping
    # Start with base score from entropy and zxcvbn
    # zxcvbn score (0-4) maps to 60 points max
    # entropy (capped at 80 bits) maps to 40 points max
    base_score = (z_score / 4.0) * 60 + (min(ent_val, 80) / 80.0) * 40
    
    # Penalize score for findings
    penalty = 0
    if length < 8:
        penalty += 30
    elif length < 12:
        penalty += 15
        
    if dict_words:
        penalty += 15
    if repeats or sequences:
        penalty += 10
    if keyboards:
        penalty += 10
    if personal_leaks:
        penalty += 20
        
    score_100 = max(0, min(100, int(base_score - penalty)))
    
    # Override scoring for super weak cases
    if length < 6:
        score_100 = min(score_100, 10)
        
    return {
        "password": password,
        "length": length,
        "diversity": diversity,
        "entropy": ent_val,
        "entropy_category": ent_category,
        "zxcvbn_score": z_score,
        "crack_time": crack_time,
        "weaknesses": weaknesses,
        "recommendations": recommendations,
        "score_100": score_100
    }
