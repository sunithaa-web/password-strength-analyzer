import os
import sys
import json
import logging
import threading
import string
import time
from typing import Dict, Any, Set
from datetime import datetime

import customtkinter as ctk
import tkinter as tk
from tkinter import filedialog, messagebox
import pyperclip

import analyzer
import wordlist_generator
import exporter
import reports

logger = logging.getLogger("PasswordAnalyzer.GUI")

# ── Theme ──────────────────────────────────────────────────────────────────────
ctk.set_appearance_mode("dark")
ctk.set_default_color_theme("blue")

# Dark palette constants  (light-mode / dark-mode tuples)
BG_CARD   = ("gray92", "#1e1e2e")   # card background
BG_INNER  = ("gray88", "#181825")   # textbox / listbox background
BG_PAGE   = ("gray98", "#13131f")   # page canvas
FG_MUTED  = "gray60"

# ── Main Application ───────────────────────────────────────────────────────────
class PasswordAnalyzerApp(ctk.CTk):
    def __init__(self):
        super().__init__()

        self.title("SentinelSec  |  Password Strength Analyzer & Wordlist Generator")
        self.geometry("1020x730")
        self.minsize(920, 680)
        self.configure(fg_color=BG_PAGE)

        # App-level state
        self.current_analysis_results = None
        self.generated_wordlist: Set[str] = set()
        self.generated_stats: dict = {}

        # ── Layout: sidebar (col 0) + content area (col 1)
        self.grid_rowconfigure(0, weight=1)
        self.grid_columnconfigure(0, minsize=210, weight=0)
        self.grid_columnconfigure(1, weight=1)

        self._build_sidebar()

        # Pages dict — each is a CTkFrame placed in col 1
        self.pages: dict = {}
        self._build_dashboard()
        self._build_analyzer_page()
        self._build_wordlist_page()

        self.show_page("dashboard")

        # Pre-warm NLTK in background so the first analysis is instant
        threading.Thread(target=analyzer.init_nltk_words, daemon=True).start()

    # ══════════════════════════════════════════════════════════════════════════
    # SIDEBAR
    # ══════════════════════════════════════════════════════════════════════════
    def _build_sidebar(self):
        sb = ctk.CTkFrame(self, width=210, corner_radius=0, fg_color=BG_CARD)
        sb.grid(row=0, column=0, sticky="nsew")
        sb.grid_propagate(False)
        sb.grid_rowconfigure(6, weight=1)

        # Logo
        ctk.CTkLabel(sb, text="  SentinelSec",
                     font=ctk.CTkFont(size=20, weight="bold"),
                     text_color="#cba6f7").grid(row=0, column=0, padx=18, pady=(28, 2), sticky="w")
        ctk.CTkLabel(sb, text="Security Auditing Suite",
                     font=ctk.CTkFont(size=11),
                     text_color=FG_MUTED).grid(row=1, column=0, padx=18, pady=(0, 22), sticky="w")

        self._nav_btns = {}
        nav_items = [
            ("dashboard", "  Home"),
            ("analyzer",  "  Password Analyzer"),
            ("wordlist",  "  Wordlist Generator"),
        ]
        for idx, (key, label) in enumerate(nav_items, start=2):
            btn = ctk.CTkButton(
                sb, text=label, height=40, anchor="w",
                font=ctk.CTkFont(size=13),
                fg_color="transparent",
                text_color=("gray10", "gray90"),
                hover_color=("gray78", "#2a2a3e"),
                command=lambda k=key: self.show_page(k)
            )
            btn.grid(row=idx, column=0, padx=12, pady=5, sticky="ew")
            self._nav_btns[key] = btn

        ctk.CTkButton(
            sb, text="Legal Disclaimer", height=26,
            font=ctk.CTkFont(size=11, underline=True),
            fg_color="transparent", text_color=FG_MUTED,
            hover_color=("gray80", "#2a2a3e"),
            command=self._show_disclaimer
        ).grid(row=7, column=0, padx=12, pady=(0, 18), sticky="sw")

    def show_page(self, name: str):
        for k, btn in self._nav_btns.items():
            btn.configure(fg_color=("gray78", "#2e2e4a") if k == name else "transparent")
        for k, frame in self.pages.items():
            if k == name:
                frame.grid(row=0, column=1, sticky="nsew", padx=24, pady=20)
            else:
                frame.grid_forget()

    # ══════════════════════════════════════════════════════════════════════════
    # PAGE 1  ─  DASHBOARD
    # ══════════════════════════════════════════════════════════════════════════
    def _build_dashboard(self):
        page = ctk.CTkFrame(self, fg_color=BG_PAGE)
        self.pages["dashboard"] = page

        ctk.CTkLabel(page, text="Welcome to SentinelSec",
                     font=ctk.CTkFont(size=28, weight="bold")).pack(anchor="w", pady=(10, 4))
        ctk.CTkLabel(page,
                     text="Advanced password auditing & custom wordlist generation for defensive security research.",
                     font=ctk.CTkFont(size=13), text_color=FG_MUTED).pack(anchor="w", pady=(0, 22))

        # Info banner
        banner = ctk.CTkFrame(page, fg_color=BG_CARD, corner_radius=12)
        banner.pack(fill="x", pady=6)
        ctk.CTkLabel(banner, text="  Educational Audit Environment",
                     font=ctk.CTkFont(size=15, weight="bold"),
                     text_color="#a6e3a1").pack(anchor="w", padx=18, pady=(16, 4))
        ctk.CTkLabel(banner,
                     text="This tool calculates bit-entropy, runs NLTK corpus matching, keyboard-sweep detection, and\n"
                          "zxcvbn cracking simulations — all locally, with no data transmitted.\n\n"
                          "The wordlist module applies leetspeak substitutions, year suffixes, symbol mutations and\n"
                          "two/three-way permutations, capped at 100,000 unique entries to stay memory-safe.",
                     font=ctk.CTkFont(size=13), justify="left",
                     text_color="gray80").pack(anchor="w", padx=18, pady=(0, 18))

        ctk.CTkLabel(page, text="Quick Actions",
                     font=ctk.CTkFont(size=16, weight="bold")).pack(anchor="w", pady=(20, 10))

        cards = ctk.CTkFrame(page, fg_color=BG_PAGE)
        cards.pack(fill="both", expand=True)
        cards.columnconfigure((0, 1), weight=1)

        for col, (title, desc, page_key, btn_text) in enumerate([
            ("Password Auditor",
             "Evaluate entropy, GPU crack-time estimates, pattern vulnerabilities, and get actionable suggestions.",
             "analyzer", "Open Analyzer"),
            ("Wordlist Permuter",
             "Build localised attack dictionaries from personal context: names, pets, birth years, cities, and more.",
             "wordlist", "Open Generator"),
        ]):
            card = ctk.CTkFrame(cards, fg_color=BG_CARD, corner_radius=12)
            card.grid(row=0, column=col, padx=(0 if col else 0, 10 if col == 0 else 0), pady=8, sticky="nsew")
            if col == 1:
                card.grid(padx=(10, 0))
            ctk.CTkLabel(card, text=title,
                         font=ctk.CTkFont(size=15, weight="bold")).pack(anchor="w", padx=18, pady=(18, 5))
            ctk.CTkLabel(card, text=desc, text_color=FG_MUTED,
                         font=ctk.CTkFont(size=12), justify="left",
                         wraplength=290).pack(anchor="w", padx=18, pady=(0, 14))
            ctk.CTkButton(card, text=btn_text,
                          command=lambda k=page_key: self.show_page(k)).pack(anchor="w", padx=18, pady=(0, 18))

    # ══════════════════════════════════════════════════════════════════════════
    # PAGE 2  ─  PASSWORD ANALYZER
    # ══════════════════════════════════════════════════════════════════════════
    def _build_analyzer_page(self):
        page = ctk.CTkFrame(self, fg_color=BG_PAGE)
        self.pages["analyzer"] = page
        page.rowconfigure(3, weight=1)
        page.columnconfigure(0, weight=1)

        # Header
        ctk.CTkLabel(page, text="Password Strength Auditor",
                     font=ctk.CTkFont(size=24, weight="bold")).grid(row=0, column=0, sticky="w", pady=(10, 4))
        ctk.CTkLabel(page,
                     text="Type a password for real-time cryptographic analysis, crack-time predictions and recommendations.",
                     font=ctk.CTkFont(size=13), text_color=FG_MUTED).grid(row=1, column=0, sticky="w", pady=(0, 18))

        # ── Input row
        input_row = ctk.CTkFrame(page, fg_color=BG_PAGE)
        input_row.grid(row=2, column=0, sticky="ew")
        input_row.columnconfigure(0, weight=1)

        self.ent_password = ctk.CTkEntry(
            input_row, placeholder_text="Enter password to analyze...",
            font=ctk.CTkFont(size=14), height=42, show="*")
        self.ent_password.grid(row=0, column=0, sticky="ew", padx=(0, 8))
        self.ent_password.bind("<KeyRelease>", lambda e: self._run_analysis())

        self.btn_toggle = ctk.CTkButton(
            input_row, text="Show", width=60, height=42,
            fg_color=BG_CARD, text_color=("gray20", "gray80"),
            command=self._toggle_visibility)
        self.btn_toggle.grid(row=0, column=1, padx=(0, 8))

        ctk.CTkButton(input_row, text="Analyze", width=100, height=42,
                      command=self._run_analysis).grid(row=0, column=2)

        # ── Score bar card
        score_card = ctk.CTkFrame(page, fg_color=BG_CARD, corner_radius=10)
        score_card.grid(row=3, column=0, sticky="ew", pady=(14, 0))

        score_row = ctk.CTkFrame(score_card, fg_color=BG_CARD)
        score_row.pack(fill="x", padx=16, pady=(12, 4))

        ctk.CTkLabel(score_row, text="Security Score:",
                     font=ctk.CTkFont(size=14, weight="bold")).pack(side="left")
        self.lbl_score_val = ctk.CTkLabel(score_row, text="0 / 100",
                                          font=ctk.CTkFont(size=14, weight="bold"))
        self.lbl_score_val.pack(side="left", padx=6)
        self.lbl_score_cat = ctk.CTkLabel(score_row, text="(Very Weak)",
                                          font=ctk.CTkFont(size=14, weight="bold"),
                                          text_color="#ff5555")
        self.lbl_score_cat.pack(side="left")

        self.pb_strength = ctk.CTkProgressBar(score_card, height=14, corner_radius=7)
        self.pb_strength.pack(fill="x", padx=16, pady=(2, 14))
        self.pb_strength.set(0)
        self.pb_strength.configure(progress_color="#ff5555")

        # ── Twin detail columns
        detail_row = ctk.CTkFrame(page, fg_color=BG_PAGE)
        detail_row.grid(row=4, column=0, sticky="nsew", pady=(14, 0))
        page.rowconfigure(4, weight=1)
        detail_row.columnconfigure((0, 1), weight=1)
        detail_row.rowconfigure(0, weight=1)

        # Left: audit stats
        lcard = ctk.CTkFrame(detail_row, fg_color=BG_CARD, corner_radius=10)
        lcard.grid(row=0, column=0, padx=(0, 8), sticky="nsew")
        lcard.rowconfigure(1, weight=1)
        ctk.CTkLabel(lcard, text="Audit Details",
                     font=ctk.CTkFont(size=14, weight="bold")).grid(row=0, column=0, sticky="w", padx=15, pady=(14, 6))
        self.txt_stats = ctk.CTkTextbox(lcard, fg_color=BG_INNER,
                                        font=ctk.CTkFont(family="Consolas", size=13),
                                        corner_radius=8)
        self.txt_stats.grid(row=1, column=0, sticky="nsew", padx=10, pady=(0, 10))
        lcard.columnconfigure(0, weight=1)
        self._set_txt(self.txt_stats, "Enter a password above to begin analysis.")

        # Right: recommendations
        rcard = ctk.CTkFrame(detail_row, fg_color=BG_CARD, corner_radius=10)
        rcard.grid(row=0, column=1, padx=(8, 0), sticky="nsew")
        rcard.rowconfigure(1, weight=1)
        ctk.CTkLabel(rcard, text="Vulnerabilities & Recommendations",
                     font=ctk.CTkFont(size=14, weight="bold")).grid(row=0, column=0, sticky="w", padx=15, pady=(14, 6))
        self.txt_recs = ctk.CTkTextbox(rcard, fg_color=BG_INNER,
                                       font=ctk.CTkFont(size=12), corner_radius=8)
        self.txt_recs.grid(row=1, column=0, sticky="nsew", padx=10, pady=(0, 10))
        rcard.columnconfigure(0, weight=1)
        self._set_txt(self.txt_recs, "Actionable recommendations will appear here.")

        # ── Action buttons
        act_row = ctk.CTkFrame(page, fg_color=BG_PAGE)
        act_row.grid(row=5, column=0, sticky="ew", pady=(12, 0))

        ctk.CTkButton(act_row, text="Copy Summary", width=140,
                      command=self._copy_to_clipboard).pack(side="left", padx=(0, 10))
        ctk.CTkButton(act_row, text="Save Audit Report (.txt)", width=185,
                      command=self._save_report).pack(side="left")

    # ── Analyzer helpers ───────────────────────────────────────────────────────
    def _toggle_visibility(self):
        if self.ent_password.cget("show") == "*":
            self.ent_password.configure(show="")
            self.btn_toggle.configure(text="Hide")
        else:
            self.ent_password.configure(show="*")
            self.btn_toggle.configure(text="Show")

    def _run_analysis(self):
        pwd = self.ent_password.get()
        if not pwd:
            self._reset_analyzer()
            return

        results = analyzer.analyze_password(pwd)
        self.current_analysis_results = results
        score = results["score_100"]

        # Score & bar
        self.lbl_score_val.configure(text=f"{score} / 100")
        self.pb_strength.set(score / 100.0)

        if score <= 20:   cat, col = "Very Weak",  "#ff5555"
        elif score <= 40: cat, col = "Weak",        "#ff944d"
        elif score <= 60: cat, col = "Moderate",    "#f1fa8c"
        elif score <= 80: cat, col = "Strong",       "#a6e3a1"
        else:             cat, col = "Very Strong",  "#50fa7b"

        self.lbl_score_cat.configure(text=f"({cat})", text_color=col)
        self.pb_strength.configure(progress_color=col)

        # Left textbox
        div_lines = "\n".join(f"  [+] {d}" for d in results["diversity"]) or "  (none)"
        stats_text = (
            f"SUMMARY\n{'─'*38}\n"
            f"Length          : {results['length']} characters\n"
            f"Bit Entropy     : {results['entropy']} bits\n"
            f"Entropy Rating  : {results['entropy_category']}\n"
            f"zxcvbn Score    : {results['zxcvbn_score']} / 4\n"
            f"Est. Crack Time : {results['crack_time']}\n\n"
            f"CHARACTER POOLS DETECTED\n{'─'*38}\n"
            f"{div_lines}"
        )
        self._set_txt(self.txt_stats, stats_text)

        # Right textbox
        rec_lines = ""
        if results["weaknesses"]:
            rec_lines += "DETECTED WEAKNESSES\n" + "─"*38 + "\n"
            for w in results["weaknesses"]:
                rec_lines += f"  [!] {w}\n"
            rec_lines += "\n"
        rec_lines += "RECOMMENDATIONS\n" + "─"*38 + "\n"
        if results["recommendations"]:
            for r in results["recommendations"]:
                rec_lines += f"  [+] {r}\n"
        else:
            rec_lines += "  [+] Excellent! No issues detected.\n"
        self._set_txt(self.txt_recs, rec_lines)

    def _reset_analyzer(self):
        self.lbl_score_val.configure(text="0 / 100")
        self.lbl_score_cat.configure(text="(Very Weak)", text_color="#ff5555")
        self.pb_strength.set(0)
        self.pb_strength.configure(progress_color="#ff5555")
        self._set_txt(self.txt_stats, "Enter a password above to begin analysis.")
        self._set_txt(self.txt_recs, "Actionable recommendations will appear here.")
        self.current_analysis_results = None

    def _copy_to_clipboard(self):
        if not self.current_analysis_results:
            messagebox.showwarning("Nothing to Copy", "Analyze a password first.")
            return
        r = self.current_analysis_results
        summary = (
            f"SentinelSec Audit Summary\n"
            f"Score          : {r['score_100']} / 100\n"
            f"Entropy        : {r['entropy']} bits ({r['entropy_category']})\n"
            f"zxcvbn         : {r['zxcvbn_score']} / 4\n"
            f"Crack Time     : {r['crack_time']}\n"
            f"Weaknesses     : {len(r['weaknesses'])}\n"
            f"Recommendations: {len(r['recommendations'])}"
        )
        try:
            pyperclip.copy(summary)
            messagebox.showinfo("Copied", "Summary copied to clipboard.")
        except Exception as exc:
            messagebox.showerror("Copy Failed", str(exc))

    def _save_report(self):
        if not self.current_analysis_results:
            messagebox.showwarning("Nothing to Save", "Analyze a password first.")
            return
        fp = filedialog.asksaveasfilename(
            defaultextension=".txt",
            filetypes=[("Text files", "*.txt"), ("All files", "*.*")],
            initialfile="password_report.txt",
            title="Save Password Audit Report")
        if fp:
            try:
                reports.generate_password_report(self.current_analysis_results, fp)
                messagebox.showinfo("Saved", f"Report saved to:\n{fp}")
            except Exception as exc:
                messagebox.showerror("Save Failed", str(exc))

    # ══════════════════════════════════════════════════════════════════════════
    # PAGE 3  ─  WORDLIST GENERATOR
    # ══════════════════════════════════════════════════════════════════════════
    def _build_wordlist_page(self):
        page = ctk.CTkFrame(self, fg_color=BG_PAGE)
        self.pages["wordlist"] = page
        page.columnconfigure(0, weight=1)

        ctk.CTkLabel(page, text="Custom Attack Wordlist Generator",
                     font=ctk.CTkFont(size=24, weight="bold")).grid(row=0, column=0, sticky="w", pady=(10, 4))
        ctk.CTkLabel(page,
                     text="Provide target context parameters to build a personalised mutation dictionary (max 100,000 entries).",
                     font=ctk.CTkFont(size=13), text_color=FG_MUTED).grid(row=1, column=0, sticky="w", pady=(0, 14))

        # ── Scrollable input form
        form = ctk.CTkScrollableFrame(page, fg_color=BG_CARD, corner_radius=10, height=210)
        form.grid(row=2, column=0, sticky="ew")
        form.grid_columnconfigure((0, 1, 2), weight=1)

        self.inputs: dict = {}
        fields = [
            ("first_name", "First Name",   "e.g. Sunita",  0, 0),
            ("last_name",  "Last Name",    "e.g. Sen",     0, 1),
            ("nickname",   "Nickname",     "e.g. Suni",    0, 2),
            ("pet_name",   "Pet Name",     "e.g. Bruno",   1, 0),
            ("birth_year", "Birth Year",   "e.g. 2006",    1, 1),
            ("birth_date", "Birth Date",   "e.g. 1506",    1, 2),
            ("phone",      "Phone Digits", "e.g. 9876",    2, 0),
            ("city",       "City",         "e.g. Chennai", 2, 1),
            ("state",      "State",        "e.g. TN",      2, 2),
            ("fav_team",   "Fav. Team",    "e.g. Dhoni",   3, 0),
            ("fav_movie",  "Fav. Movie",   "e.g. Avatar",  3, 1),
        ]
        for key, label, ph, r, c in fields:
            ctk.CTkLabel(form, text=label,
                         font=ctk.CTkFont(size=12, weight="bold")).grid(
                row=r * 2, column=c, padx=12, pady=(10, 2), sticky="w")
            ent = ctk.CTkEntry(form, placeholder_text=ph, height=34)
            ent.grid(row=r * 2 + 1, column=c, padx=10, pady=(0, 8), sticky="ew")
            self.inputs[key] = ent

        # ── Options row
        opt_row = ctk.CTkFrame(page, fg_color=BG_PAGE)
        opt_row.grid(row=3, column=0, sticky="ew", pady=(10, 0))
        ctk.CTkLabel(opt_row, text="Max Words:",
                     font=ctk.CTkFont(size=12, weight="bold")).pack(side="left", padx=(0, 8))
        self.opt_limit = ctk.CTkOptionMenu(opt_row,
                                           values=["5000", "10000", "25000", "50000", "100000"],
                                           width=100)
        self.opt_limit.set("100000")
        self.opt_limit.pack(side="left", padx=(0, 20))
        self.btn_generate = ctk.CTkButton(opt_row, text="  Generate Wordlist",
                                          height=38, command=self._generate_wordlist)
        self.btn_generate.pack(side="right", fill="x", expand=True)

        # Progress bar
        self.pb_gen = ctk.CTkProgressBar(page, height=6, corner_radius=3)
        self.pb_gen.grid(row=4, column=0, sticky="ew", pady=(8, 0))
        self.pb_gen.set(0)

        # ── Results columns
        res_row = ctk.CTkFrame(page, fg_color=BG_PAGE)
        res_row.grid(row=5, column=0, sticky="nsew", pady=(12, 0))
        page.rowconfigure(5, weight=1)
        res_row.columnconfigure((0, 1), weight=1)
        res_row.rowconfigure(0, weight=1)

        # Stats card
        sc = ctk.CTkFrame(res_row, fg_color=BG_CARD, corner_radius=10)
        sc.grid(row=0, column=0, padx=(0, 8), sticky="nsew")
        sc.rowconfigure(1, weight=1)
        sc.columnconfigure(0, weight=1)
        ctk.CTkLabel(sc, text="Generation Stats",
                     font=ctk.CTkFont(size=14, weight="bold")).grid(row=0, column=0, sticky="w", padx=15, pady=(14, 6))
        self.txt_gen_stats = ctk.CTkTextbox(sc, fg_color=BG_INNER,
                                            font=ctk.CTkFont(family="Consolas", size=13),
                                            corner_radius=8)
        self.txt_gen_stats.grid(row=1, column=0, sticky="nsew", padx=10, pady=(0, 10))
        self._set_txt(self.txt_gen_stats, "Stats will appear here after generation.")

        # Preview card
        pc = ctk.CTkFrame(res_row, fg_color=BG_CARD, corner_radius=10)
        pc.grid(row=0, column=1, padx=(8, 0), sticky="nsew")
        pc.rowconfigure(1, weight=1)
        pc.columnconfigure(0, weight=1)
        ctk.CTkLabel(pc, text="Preview (first 100)",
                     font=ctk.CTkFont(size=14, weight="bold")).grid(row=0, column=0, sticky="w", padx=15, pady=(14, 6))
        self.list_preview = tk.Listbox(
            pc, bg="#181825", fg="#cdd6f4",
            selectbackground="#3b8ed0", activestyle="none",
            font=("Consolas", 11), bd=0, highlightthickness=0, relief="flat")
        self.list_preview.grid(row=1, column=0, sticky="nsew", padx=10, pady=(0, 10))

        # Export row
        exp_row = ctk.CTkFrame(page, fg_color=BG_PAGE)
        exp_row.grid(row=6, column=0, sticky="ew", pady=(10, 0))
        self.btn_save_wl = ctk.CTkButton(exp_row, text="Save Wordlist (.txt)",
                                         state="disabled", height=36,
                                         command=self._save_wordlist)
        self.btn_save_wl.pack(side="left", fill="x", expand=True, padx=(0, 10))
        self.btn_save_stats = ctk.CTkButton(exp_row, text="Export Stats (.json)",
                                            state="disabled", height=36,
                                            command=self._save_stats_json)
        self.btn_save_stats.pack(side="right", fill="x", expand=True)

    # ── Wordlist helpers ───────────────────────────────────────────────────────
    def _generate_wordlist(self):
        user_info = {k: e.get().strip() for k, e in self.inputs.items()}
        if not any(user_info.values()):
            messagebox.showwarning("No Input", "Fill in at least one field before generating.")
            return

        max_sz = int(self.opt_limit.get())
        self.btn_generate.configure(state="disabled", text="  Generating...")
        self.btn_save_wl.configure(state="disabled")
        self.btn_save_stats.configure(state="disabled")
        self.pb_gen.configure(mode="indeterminate")
        self.pb_gen.start()

        def _worker():
            t0 = time.time()
            wl = wordlist_generator.generate_custom_wordlist(user_info, max_size=max_sz)
            duration = time.time() - t0
            words = sorted(wl)
            total_bytes = sum(len(w.encode("utf-8")) + 1 for w in words)
            kb = total_bytes / 1024.0
            sz_fmt = f"{kb/1024:.2f} MB" if kb >= 1024 else f"{kb:.2f} KB"
            n = len(words)
            stats = {
                "total_words": n, "unique_words": n,
                "file_size_formatted": sz_fmt,
                "created": datetime.now().strftime("%Y-%m-%d"),
                "source": "custom generator",
                "duration_sec": round(duration, 4),
                "cracking_coverage": {
                    "online_100_per_sec": f"{n/100:.2f}s",
                    "offline_100k_per_sec": f"{n/100000:.4f}s",
                    "gpu_10m_per_sec": f"{n/10000000:.6f}s",
                }
            }
            self.after(0, self._on_generation_done, words, stats)

        threading.Thread(target=_worker, daemon=True).start()

    def _on_generation_done(self, words: list, stats: dict):
        self.generated_wordlist = set(words)
        self.generated_stats = stats

        self.pb_gen.stop()
        self.pb_gen.configure(mode="determinate")
        self.pb_gen.set(1.0)
        self.btn_generate.configure(state="normal", text="  Generate Wordlist")
        self.btn_save_wl.configure(state="normal")
        self.btn_save_stats.configure(state="normal")

        cv = stats["cracking_coverage"]
        stats_text = (
            f"GENERATION METRICS\n{'─'*38}\n"
            f"Total Unique Words : {stats['total_words']:,}\n"
            f"Est. File Size     : {stats['file_size_formatted']}\n"
            f"Build Time         : {stats['duration_sec']}s\n\n"
            f"CRACKING DURATION ESTIMATES\n{'─'*38}\n"
            f"Online  (100/s)    : {cv['online_100_per_sec']}\n"
            f"Offline (100k/s)   : {cv['offline_100k_per_sec']}\n"
            f"GPU     (10M/s)    : {cv['gpu_10m_per_sec']}"
        )
        self._set_txt(self.txt_gen_stats, stats_text)

        self.list_preview.delete(0, tk.END)
        for i, w in enumerate(words[:100]):
            self.list_preview.insert(tk.END, f" {i+1:03d}  {w}")
        if len(words) > 100:
            self.list_preview.insert(tk.END, f"  ... and {len(words)-100:,} more entries")

    def _save_wordlist(self):
        if not self.generated_wordlist:
            return
        fp = filedialog.asksaveasfilename(
            defaultextension=".txt",
            filetypes=[("Text files", "*.txt"), ("All", "*.*")],
            initialfile="custom_wordlist.txt",
            title="Save Wordlist")
        if fp:
            try:
                exporter.export_wordlist(self.generated_wordlist,
                                         output_dir=os.path.dirname(fp),
                                         filename=os.path.basename(fp))
                messagebox.showinfo("Saved", f"Wordlist saved to:\n{fp}")
            except Exception as exc:
                messagebox.showerror("Error", str(exc))

    def _save_stats_json(self):
        if not self.generated_stats:
            return
        fp = filedialog.asksaveasfilename(
            defaultextension=".json",
            filetypes=[("JSON", "*.json"), ("All", "*.*")],
            initialfile="stats.json",
            title="Save Stats")
        if fp:
            try:
                with open(fp, "w", encoding="utf-8") as f:
                    json.dump(self.generated_stats, f, indent=4)
                messagebox.showinfo("Saved", f"Stats saved to:\n{fp}")
            except Exception as exc:
                messagebox.showerror("Error", str(exc))

    # ══════════════════════════════════════════════════════════════════════════
    # SHARED UTILITIES
    # ══════════════════════════════════════════════════════════════════════════
    @staticmethod
    def _set_txt(widget: ctk.CTkTextbox, text: str):
        """Helper: enable, replace content, then disable a CTkTextbox."""
        widget.configure(state="normal")
        widget.delete("1.0", "end")
        widget.insert("1.0", text)
        widget.configure(state="disabled")

    def _show_disclaimer(self):
        messagebox.showwarning(
            "Legal Disclaimer",
            "SENTINELSEC — LEGAL DISCLAIMER\n\n"
            "This tool is designed solely for educational, defensive security research,\n"
            "and personal password auditing purposes.\n\n"
            "Unauthorized credential harvesting, password cracking, or use against\n"
            "systems without explicit written authorization is illegal and prohibited.\n\n"
            "By using this tool you agree to use it lawfully and responsibly."
        )


# ── Entry point ────────────────────────────────────────────────────────────────
def launch_gui():
    app = PasswordAnalyzerApp()
    app.mainloop()


if __name__ == "__main__":
    launch_gui()
