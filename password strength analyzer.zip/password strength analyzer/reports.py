from datetime import datetime
from typing import Dict, Any

def generate_password_report(analysis_results: Dict[str, Any], filepath: str = "password_report.txt") -> str:
    """
    Generates a structured, clean, and educational password audit report.
    Saves it to filepath and returns the content as a string.
    """
    password = analysis_results.get("password", "")
    # Mask password for security in reports
    if len(password) <= 2:
        masked_password = "*" * len(password)
    else:
        masked_password = password[0] + "*" * (len(password) - 2) + password[-1]
    
    length = analysis_results.get("length", 0)
    entropy = analysis_results.get("entropy", 0.0)
    entropy_category = analysis_results.get("entropy_category", "N/A")
    zxcvbn_score = analysis_results.get("zxcvbn_score", 0)
    crack_time = analysis_results.get("crack_time", "Unknown")
    
    weaknesses = analysis_results.get("weaknesses", [])
    recommendations = analysis_results.get("recommendations", [])
    
    # Format recommendations with check marks
    rec_text = ""
    if recommendations:
        rec_text = "\n".join([f" [+] {rec}" for rec in recommendations])
    else:
        rec_text = " [+] None! Your password meets our security guidelines."
        
    weakness_text = ""
    if weaknesses:
        weakness_text = "\n".join([f" - [!] {weak}" for weak in weaknesses])
    else:
        weakness_text = " - No structural weaknesses detected."
        
    report = f"""==================================================
PASSWORD STRENGTH AUDIT REPORT
Generated on: {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}
==================================================

1. PASSWORD SUMMARY
--------------------------------------------------
Masked Password:      {masked_password}
Length:               {length} characters
Calculated Entropy:   {entropy} bits
Entropy Strength:     {entropy_category}
zxcvbn Score:         {zxcvbn_score}/4
Est. Crack Time:      {crack_time}

2. VULNERABILITY ANALYSIS & WEAKNESSES
--------------------------------------------------
{weakness_text}

3. ACTIONABLE RECOMMENDATIONS
--------------------------------------------------
{rec_text}

==================================================
DISCLAIMER: This report is for educational and
defensive auditing purposes. Keep passwords secret!
==================================================
"""
    with open(filepath, 'w', encoding='utf-8') as f:
        f.write(report)
        
    return report
