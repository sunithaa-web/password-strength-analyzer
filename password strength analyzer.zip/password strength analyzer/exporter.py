import os
import json
from datetime import datetime
from typing import Set, Dict, Any

def export_wordlist(wordlist: Set[str], output_dir: str = "output", filename: str = "custom_wordlist.txt") -> Dict[str, Any]:
    """
    Exports a set of words to custom_wordlist.txt in the specified output directory.
    Saves metadata about the export (stats.json) and calculates cracking times at various speeds.
    """
    # Ensure output directory exists
    os.makedirs(output_dir, exist_ok=True)
    
    filepath = os.path.join(output_dir, filename)
    
    # Deduplicate and sort alphabetically
    sorted_words = sorted(list(wordlist))
    
    # Write words to file
    with open(filepath, 'w', encoding='utf-8') as f:
        for word in sorted_words:
            f.write(f"{word}\n")
            
    # Calculate file size
    file_size_bytes = os.path.getsize(filepath)
    file_size_kb = file_size_bytes / 1024.0
    
    if file_size_kb >= 1024.0:
        file_size_formatted = f"{file_size_kb / 1024.0:.2f} MB"
    else:
        file_size_formatted = f"{file_size_kb:.2f} KB"
        
    # Calculate hypothetical cracking duration at different testing rates
    # 100 guesses/sec (standard online rate-limited API)
    # 100,000 guesses/sec (standard cracking software over standard networks)
    # 10,000,000 guesses/sec (GPU brute-forcing local hashes, e.g., MD5/SHA256)
    unique_count = len(sorted_words)
    
    time_online_slow = unique_count / 100.0
    time_offline_med = unique_count / 100000.0
    time_offline_fast = unique_count / 10000000.0
    
    stats = {
        "total_words": unique_count,  # Output is pre-deduplicated
        "unique_words": unique_count,
        "file_size_bytes": file_size_bytes,
        "file_size_formatted": file_size_formatted,
        "created": datetime.now().strftime("%Y-%m-%d"),
        "source": "custom generator",
        "cracking_coverage": {
            "online_100_guesses_per_sec": f"{time_online_slow:.2f} seconds",
            "offline_100k_guesses_per_sec": f"{time_offline_med:.4f} seconds",
            "offline_10m_guesses_per_sec": f"{time_offline_fast:.6f} seconds"
        }
    }
    
    # Write stats to stats.json
    stats_path = os.path.join(output_dir, "stats.json")
    with open(stats_path, 'w', encoding='utf-8') as f:
        json.dump(stats, f, indent=4)
        
    return stats
