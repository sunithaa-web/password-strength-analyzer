import math
import string

def calculate_entropy(password: str) -> float:
    """
    Calculates the information entropy of a password.
    Formula: Entropy = Length * log2(Character Set Size)
    
    Character Set Sizes:
    - Lowercase letters (a-z): 26
    - Uppercase letters (A-Z): 26
    - Digits (0-9): 10
    - Symbols/Punctuation: 32 (standard printable ASCII symbols)
    - Other characters: 32 (fallback for whitespace and unicode characters)
    """
    if not password:
        return 0.0

    length = len(password)
    pool_size = 0
    
    has_lower = False
    has_upper = False
    has_digit = False
    has_special = False
    has_other = False

    for char in password:
        if char.islower():
            has_lower = True
        elif char.isupper():
            has_upper = True
        elif char.isdigit():
            has_digit = True
        elif char in string.punctuation:
            has_special = True
        else:
            has_other = True

    if has_lower:
        pool_size += 26
    if has_upper:
        pool_size += 26
    if has_digit:
        pool_size += 10
    if has_special:
        pool_size += 32
    if has_other:
        pool_size += 32  # Add buffer for spaces or unicode characters

    if pool_size == 0:
        return 0.0

    entropy = length * math.log2(pool_size)
    return round(entropy, 2)

def get_strength_category(entropy: float) -> str:
    """
    Categorizes the password strength based on entropy values:
    - < 28 bits: Very Weak (easily brute-forced instantly)
    - 28 to < 36 bits: Weak (brute-forced very quickly)
    - 36 to < 60 bits: Moderate (reasonable protection against offline attacks)
    - 60 to < 128 bits: Strong (secure for standard accounts)
    - >= 128 bits: Very Strong (cryptographically secure)
    """
    if entropy < 28:
        return "Very Weak"
    elif entropy < 36:
        return "Weak"
    elif entropy < 60:
        return "Moderate"
    elif entropy < 128:
        return "Strong"
    else:
        return "Very Strong"
