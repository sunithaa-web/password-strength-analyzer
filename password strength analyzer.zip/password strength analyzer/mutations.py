import itertools
import logging
from typing import Set, List

logger = logging.getLogger("PasswordAnalyzer")

# Core Leetspeak mapping requested by requirements
LEET_MAPPING = {
    'a': ['4'],
    'e': ['3'],
    'i': ['1'],
    'o': ['0'],
    's': ['5'],
    't': ['7']
}

COMMON_YEARS = ['2020', '2021', '2022', '2023', '2024', '2025', '2026']
SPECIAL_CHARS = ['!', '@', '#', '$', '%', '&', '*']

def get_case_variants(word: str) -> Set[str]:
    """Generates standard casing variants of a word (lowercase, uppercase, capitalized, original)."""
    if not word:
        return set()
    return {word, word.lower(), word.upper(), word.capitalize()}

def generate_leetspeak(word: str) -> Set[str]:
    """
    Generates leetspeak mutations of a word using mapping:
    a->4, e->3, i->1, o->0, s->5, t->7.
    Returns a set of mutations preserving casings where possible.
    """
    if not word:
        return set()
    
    variants = get_case_variants(word)
    leet_results = set()

    for variant in variants:
        # Build options for each character in this variant
        options = []
        for char in variant:
            char_opts = [char]
            char_lower = char.lower()
            if char_lower in LEET_MAPPING:
                # Add leet substitutions
                for replacement in LEET_MAPPING[char_lower]:
                    # Match casing style if replacement were alpha, but they are numbers here
                    char_opts.append(replacement)
            options.append(char_opts)
            
        # Generate combinations
        for combo in itertools.product(*options):
            leet_results.add("".join(combo))
            
    return leet_results

def append_years(word: str, birth_year: str = None) -> Set[str]:
    """
    Appends common years (2020-2026) and the user's birth year (if provided)
    using empty, @, or # separators.
    """
    if not word:
        return set()
        
    years = list(COMMON_YEARS)
    if birth_year and birth_year not in years:
        years.append(birth_year)
        
    mutated = set()
    separators = ['', '@', '#']
    
    for year in years:
        for sep in separators:
            mutated.add(f"{word}{sep}{year}")
            
    return mutated

def append_special_characters(word: str) -> Set[str]:
    """Appends special characters to a word (e.g. Word!, Word@)."""
    if not word:
        return set()
        
    mutated = set()
    for char in SPECIAL_CHARS:
        mutated.add(f"{word}{char}")
    return mutated

def generate_mutations_for_base_word(word: str, birth_year: str = None) -> Set[str]:
    """Generates all simple mutations (casing, leetspeak, years, specials) for a single base word."""
    if not word:
        return set()
        
    results = set()
    
    # 1. Base Casing
    cases = get_case_variants(word)
    results.update(cases)
    
    # 2. Leet variants
    leets = set()
    for w in cases:
        leets.update(generate_leetspeak(w))
    results.update(leets)
    
    # 3. Base + Years
    with_years = set()
    for w in results:
        with_years.update(append_years(w, birth_year))
    
    # 4. Base + Specials & Base + Years + Specials
    specials = set()
    for w in results:
        specials.update(append_special_characters(w))
    for wy in with_years:
        specials.update(append_special_characters(wy))
        
    results.update(with_years)
    results.update(specials)
    
    return results

def run_permutation_engine(user_info: dict, max_size: int = 100000) -> Set[str]:
    """
    Generates permutations of multiple user info attributes.
    Combines fields like Name+Pet, Pet+BirthYear, City+Year etc.,
    applies mutations, and caps total results to max_size.
    """
    # Extract and filter empty values
    clean_info = {k: v.strip() for k, v in user_info.items() if v and v.strip()}
    if not clean_info:
        return set()
        
    wordlist = set()
    
    # Extract specific components
    first_name = clean_info.get("first_name", "")
    last_name = clean_info.get("last_name", "")
    nickname = clean_info.get("nickname", "")
    pet_name = clean_info.get("pet_name", "")
    birth_year = clean_info.get("birth_year", "")
    city = clean_info.get("city", "")
    state = clean_info.get("state", "")
    fav_team = clean_info.get("fav_team", "")
    fav_movie = clean_info.get("fav_movie", "")
    phone = clean_info.get("phone", "")
    
    # Generate list of primary values
    primary_values = list(clean_info.values())
    
    # Add simple individual mutations
    for val in primary_values:
        wordlist.update(generate_mutations_for_base_word(val, birth_year))
        if len(wordlist) >= max_size:
            break
            
    if len(wordlist) >= max_size:
        return set(list(wordlist)[:max_size])
        
    # Generate pairwise combinations (e.g., SunitaBruno, BrunoSunita)
    pair_sources = [
        (first_name, last_name),
        (first_name, nickname),
        (first_name, pet_name),
        (pet_name, first_name),
        (first_name, birth_year),
        (pet_name, birth_year),
        (city, birth_year),
        (fav_team, birth_year),
        (first_name, city),
    ]
    
    # Filter empty pairs
    valid_pairs = []
    for a, b in pair_sources:
        if a and b:
            valid_pairs.append((a, b))
            
    # Add pairs directly and mutations
    for a, b in valid_pairs:
        # direct concat
        combos = [f"{a}{b}", f"{b}{a}"]
        # with separators
        for sep in ['', '@', '#', '_']:
            combos.append(f"{a}{sep}{b}")
            combos.append(f"{b}{sep}{a}")
            
        for c in combos:
            wordlist.update(get_case_variants(c))
            wordlist.update(generate_leetspeak(c))
            wordlist.update(append_special_characters(c))
            if len(wordlist) >= max_size:
                return set(list(wordlist)[:max_size])

    # Three-way combinations (e.g. SunitaBruno2006)
    triplet_sources = [
        (first_name, pet_name, birth_year),
        (first_name, last_name, birth_year),
    ]
    
    for a, b, c in triplet_sources:
        if a and b and c:
            combos = [
                f"{a}{b}{c}",
                f"{b}{a}{c}",
                f"{a}_{b}_{c}",
                f"{a}@{b}#{c}"
            ]
            for combo in combos:
                wordlist.update(get_case_variants(combo))
                wordlist.update(generate_leetspeak(combo))
                wordlist.update(append_special_characters(combo))
                if len(wordlist) >= max_size:
                    return set(list(wordlist)[:max_size])

    # Clean the wordlist (remove extremely short words, e.g. length < 3 unless it's a direct input)
    # Filter out empty strings
    wordlist = {w for w in wordlist if w}
    
    if len(wordlist) > max_size:
        wordlist = set(list(wordlist)[:max_size])
        
    return wordlist
