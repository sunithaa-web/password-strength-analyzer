# 🛡️ SentinelSec — Password Strength Analyzer & Custom Wordlist Generator

> **Educational & Defensive Security Use Only.**  
> This tool is intended solely for academic demonstrations, portfolio development, cybersecurity internships, and ethical defensive auditing. Unauthorized use against systems without explicit permission is prohibited.

---

## 📋 Table of Contents
- [Overview](#overview)
- [Architecture Diagram](#architecture-diagram)
- [Features](#features)
- [Project Structure](#project-structure)
- [Installation Guide](#installation-guide)
- [Usage Guide](#usage-guide)
  - [Launching the GUI](#launching-the-gui)
  - [CLI: Analyze a Password](#cli-analyze-a-password)
  - [CLI: Generate Wordlist](#cli-generate-wordlist)
  - [CLI: Export Stats](#cli-export-stats)
- [Module Breakdown](#module-breakdown)
- [Entropy & Score Methodology](#entropy--score-methodology)
- [Mutation Rules Reference](#mutation-rules-reference)
- [Future Enhancements](#future-enhancements)

---

## Overview

SentinelSec is a Python 3.10+ modular cybersecurity utility combining:

- **Advanced password strength evaluation** using entropy mathematics and the industry-standard `zxcvbn` library.
- **Pattern vulnerability detection** — keyboard sweeps, sequential runs, dictionary word containment (NLTK corpus), and personal data exposure.
- **Custom attack wordlist permutation** — generates mutation-based dictionary lists from personal context data using leetspeak, year appending, special character mutations, and itertools permutations.
- **Both GUI and CLI** — a premium dark-mode `CustomTkinter` UI and a full `argparse` CLI interface.

---

## Architecture Diagram

```
┌──────────────────────────────────────────────────────────────────────┐
│                       SENTINELSEC AUDIT SUITE                        │
│                                                                      │
│    ┌─────────┐          ┌────────────┐          ┌───────────────┐    │
│    │  main.py│─── CLI──▶│ analyzer.py│──────────▶│   entropy.py  │    │
│    │ (Entry  │          │ (Strength  │          │ (Bit Entropy  │    │
│    │  Point) │          │  Engine)   │          │  Calculator)  │    │
│    └────┬────┘          └─────┬──────┘          └───────────────┘    │
│         │                    │                                        │
│         │ GUI                │ weaknesses & score                     │
│         ▼                    ▼                                        │
│    ┌─────────┐          ┌────────────┐          ┌───────────────┐    │
│    │  gui.py │          │  reports.py│          │   mutations.py │    │
│    │ (CTk    │          │ (Report    │          │ (Leet + Year + │    │
│    │  GUI)   │          │  Writer)   │          │  Specials +    │    │
│    └────┬────┘          └────────────┘          │  Permutations) │    │
│         │                                       └──────┬─────────┘    │
│         │ wordlist fields                              │               │
│         ▼                                             ▼               │
│    ┌──────────────────────┐               ┌─────────────────────┐    │
│    │  wordlist_generator.py│──────────────▶│    exporter.py      │    │
│    │  (User info wrapper)  │               │ (Write .txt + JSON) │    │
│    └──────────────────────┘               └─────────────────────┘    │
│                                                                      │
│    output/                                                           │
│    ├── custom_wordlist.txt                                           │
│    └── stats.json                                                    │
└──────────────────────────────────────────────────────────────────────┘
```

---

## Password Analysis Flowchart

```
START
  │
  ├──▶ Receive Password Input
  │
  ├──▶ [entropy.py] Calculate Bit Entropy
  │         │── Detect character pools (lower/upper/digit/symbol)
  │         └── Entropy = Length × log₂(Pool Size)
  │
  ├──▶ [analyzer.py] Run Pattern Checks
  │         │── Repeated characters? (e.g. aaaa, 1111)
  │         │── Sequential runs? (e.g. 1234, abcd)
  │         │── Keyboard patterns? (e.g. qwerty, asdf)
  │         │── NLTK dictionary word containment?
  │         └── Personal info exposure? (name/pet/city/year)
  │
  ├──▶ [zxcvbn] Run Cracking Simulation
  │         │── Score (0-4)
  │         │── GPU crack time estimation
  │         └── Automated suggestions
  │
  ├──▶ Compile Score (0-100)
  │         │── Penalty: +short length, +dict match, +keyboard
  │         └── Final score = base entropy + zxcvbn - penalties
  │
  ├──▶ [reports.py] Write password_report.txt
  │
  └──▶ Display Results (CLI / GUI)

END
```

---

## Features

| Feature | Status |
|---|---|
| Password entropy calculation | ✅ |
| zxcvbn crack time estimation | ✅ |
| NLTK dictionary word check | ✅ (with offline fallback) |
| Repeated / sequential / keyboard patterns | ✅ |
| Personal info exposure warning | ✅ |
| Leetspeak mutations (a→4, e→3, i→1, o→0, s→5, t→7) | ✅ |
| Year suffix engine (2020–2026 + custom year) | ✅ |
| Special character mutations (! @ # $ % & *) | ✅ |
| Permutation combiner (two + three-way) | ✅ |
| Custom wordlist export (.txt) | ✅ |
| Statistics metadata (stats.json) | ✅ |
| Password audit report (.txt) | ✅ |
| Visual strength meter (color-coded 0-100) | ✅ |
| Dark mode GUI (CustomTkinter) | ✅ |
| Password visibility toggle | ✅ |
| Copy analysis to clipboard | ✅ |
| Real-time analysis on keystroke | ✅ |
| Wordlist preview window | ✅ |
| Progress bars for wordlist generation | ✅ |
| Error handling + logging system | ✅ |
| CLI via argparse | ✅ |
| Max wordlist safety cap (100,000) | ✅ |

---

## Project Structure

```
password strength analyzer/
│
├── main.py                   # CLI Entrypoint + argparse subcommands
├── analyzer.py               # Main password evaluation engine
├── entropy.py                # Entropy formula + strength categorization
├── wordlist_generator.py     # User info to wordlist wrapper
├── mutations.py              # Leetspeak, years, symbols, permutations
├── exporter.py               # Output writer (txt + stats.json)
├── reports.py                # Report formatter (password_report.txt)
├── gui.py                    # CustomTkinter dark GUI application
│
├── output/
│   ├── custom_wordlist.txt   # Generated wordlist (created on export)
│   └── stats.json            # Metadata (created on export)
│
├── requirements.txt          # Python dependencies
├── README.md                 # This documentation file
└── password_analyzer.log     # Runtime log (created on first run)
```

---

## Installation Guide

### Prerequisites
- Python 3.10 or higher
- pip package manager
- Windows / Linux / macOS

### Step 1 — Clone or Download the Project

```bash
# If using git:
git clone https://github.com/yourname/sentinelsec.git
cd sentinelsec

# OR just navigate to the project folder:
cd "password strength analyzer"
```

### Step 2 — Install Dependencies

```bash
pip install -r requirements.txt
```

This installs:
- `zxcvbn` — Advanced password strength estimation library
- `nltk` — Natural Language ToolKit (for dictionary word corpus)
- `customtkinter` — Modern Tkinter UI wrapper (dark mode)
- `pyperclip` — Cross-platform clipboard copy support

### Step 3 — First Run (NLTK Dictionary Download)

On first analysis execution, NLTK will automatically attempt to download the `words` corpus (~2MB). If offline, an internal fallback dictionary list is used automatically.

---

## Usage Guide

### Launching the GUI

```bash
python main.py
# OR
python main.py --gui
```

This launches the full dark-mode graphical interface.

---

### CLI: Analyze a Password

```bash
python main.py analyze --password "Summer2025!"
```

**With personal info context (detects data exposure):**
```bash
python main.py analyze --password "Sunita2006!" \
  --first_name Sunita \
  --pet_name Bruno \
  --birth_year 2006 \
  --city Chennai
```

**Save an audit report:**
```bash
python main.py analyze --password "MyPassword123!" --report
```

**Sample Output:**
```
==================================================
PASSWORD ANALYSIS RESULTS
==================================================
Password Evaluated:    Summer2025!
Length:                11 characters
Entropy:               72.67 bits (Strong)
zxcvbn Score:          3/4
Est. Crack Time:       centuries
Visual Score Score:    57/100
--------------------------------------------------
Weaknesses Detected:
  [!] Password length is weak (8-12 characters)
  [!] Contains dictionary word: 'summer'
--------------------------------------------------
Suggestions & Actionable Steps:
  ✓ Increase password length to at least 12-16 characters
  ✓ Avoid common dictionary words or dictionary phrases
==================================================
```

---

### CLI: Generate Wordlist

**Basic generation:**
```bash
python main.py generate --name Sunita --pet Bruno --year 2006
```

**Full generation with all fields:**
```bash
python main.py generate \
  --first_name Sunita \
  --last_name Sen \
  --nickname Suni \
  --pet_name Bruno \
  --birth_year 2006 \
  --city Chennai \
  --fav_team Dhoni \
  --max_words 50000
```

**Sample Output:**
```
==================================================
WORDLIST GENERATION SUMMARY
==================================================
Total Words Generated:   24,998
Unique Words:            24,998
Output File Size:        2.80 MB
Output Path:             output/custom_wordlist.txt
Metadata Path:           output/stats.json
--------------------------------------------------
Estimated Cracking Coverage:
  Online 100 Guesses Per Sec: 249.98 seconds
  Offline 100K Guesses Per Sec: 0.2500 seconds
  Offline 10M Guesses Per Sec: 0.002500 seconds
==================================================
```

---

### CLI: Export Stats

```bash
python main.py export
```

Reads and displays the last generated wordlist statistics from `output/stats.json`.

---

## Module Breakdown

| Module | Responsibility |
|---|---|
| `entropy.py` | Computes `E = L × log₂(R)` from detected character pools |
| `analyzer.py` | Coordinates all checks, computes unified 0-100 score |
| `mutations.py` | Leetspeak, year appending, special chars, permutations |
| `wordlist_generator.py` | Collects and normalizes user fields before mutation |
| `exporter.py` | Writes sorted `.txt`, generates `stats.json` metadata |
| `reports.py` | Formats and saves `password_report.txt` audit files |
| `gui.py` | CustomTkinter 3-page sidebar app with real-time meter |
| `main.py` | CLI parser using `argparse`, delegates to all modules |

---

## Entropy & Score Methodology

### Entropy Formula
```
Entropy = Password_Length × log₂(Character_Pool_Size)
```

| Pool Component | Size |
|---|---|
| Lowercase letters (a-z) | 26 |
| Uppercase letters (A-Z) | 26 |
| Digits (0-9) | 10 |
| Symbols/Punctuation | 32 |

### Entropy Categories

| Bits | Rating |
|---|---|
| < 28 | Very Weak |
| 28 – 35 | Weak |
| 36 – 59 | Moderate |
| 60 – 127 | Strong |
| ≥ 128 | Very Strong |

### Visual Score (0-100) Composition
- **zxcvbn score** (0–4) → max 60 points
- **Bit entropy** (capped 80 bits) → max 40 points
- **Penalties**: short length (-15 to -30), dictionary match (-15), keyboard/repeat pattern (-10), personal info exposure (-20)

---

## Mutation Rules Reference

### Leetspeak Map
| Original | Leet |
|---|---|
| a | 4 |
| e | 3 |
| i | 1 |
| o | 0 |
| s | 5 |
| t | 7 |

### Year Suffixes
`2020, 2021, 2022, 2023, 2024, 2025, 2026` + user birth year  
Separators: `""`, `"@"`, `"#"`

### Special Character Mutations
`!  @  #  $  %  &  *`

### Permutation Example (Name=Sunita, Pet=Bruno, Year=2006)
```
Sunita           sunita          SUNITA
Bruno            bruno           BRUNO
SunitaBruno      BrunoSunita     sunita_bruno
5un1ta           Brun0           5UN1TA
Sunita2006       Bruno2006       Sunita@2006
SunitaBruno2006  Sunita2026!     Brun02006#
... (up to 100,000 unique entries)
```

---

## Future Enhancements

- [ ] **HaveIBeenPwned API Integration** — Check passwords against leaked database hashes (k-anonymity model)
- [ ] **Passphrase Generator** — EFF-style random diceware phrase builder (stronger alternative suggestions)
- [ ] **Regex Pattern Builder** — Configurable mutation rules via JSON config file
- [ ] **Hashcat Rule Engine Export** — Export mutation rules as Hashcat `.rule` files
- [ ] **Password Manager Integration** — Import/export via CSV for Bitwarden / KeePass formats
- [ ] **Markov Chain Generator** — Probabilistic wordlist construction from corpus
- [ ] **Web Interface** — Flask/FastAPI REST API backend + React frontend
- [ ] **Batch Analysis Mode** — Analyze a list of passwords from a text file
- [ ] **PDF Report Generation** — Export audit reports as styled PDF files

---

## Legal Disclaimer

> **This tool is intended solely for educational, defensive security, and password auditing purposes.**
> Unauthorized password cracking or misuse against systems without permission is illegal and strictly prohibited.
> The author assumes no responsibility for malicious misuse.

---

*Built with ❤️ for the cybersecurity learning community.*
